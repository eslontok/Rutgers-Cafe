API Level: 28 (Pie)
AVD: Pixel 2